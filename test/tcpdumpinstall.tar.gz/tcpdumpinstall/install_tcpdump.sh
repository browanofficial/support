#! /bin/sh
#
chmod +x tcpdump
chmod +x libpcap.so.1.8.1
cp tcpdump /usr/sbin/tcpdump
ln -sf libpcap.so.1.8.1 libpcap.so.1
ln -sf libpcap.so.1 libpcap.so
cp libpcap.so.1.8.1 /usr/lib/libpcap.so.1.8.1
mv libpcap.so.1 /usr/lib/libpcap.so.1
mv libpcap.so /usr/lib/libpcap.so

